/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warnetrental;

public class Main {
    public static void main(String[] args) {
        
        WarnetRental warnetrental = new WarnetRental();
        rentalPC rentalPC = new rentalPC(1, 3000);
        rentalPS4 rentalPS4 = new rentalPS4(2, 8000);
        
        // memanggil method harga total
        warnetrental.hargaTotal();
        System.out.println("");
        
        System.out.println("Total harga rental PC sesuai waktu yang dihabiskan = Rp "+rentalPC.hargaTotal());
        System.out.println("Total harga rental PS4 sesuai waktu yang dihabiskan = Rp "+rentalPS4.hargaTotal());
        
    }
    
}
