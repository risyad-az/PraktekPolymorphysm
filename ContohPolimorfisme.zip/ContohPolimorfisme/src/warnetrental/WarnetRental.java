/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warnetrental;

public class WarnetRental {
    float hargaTotal() {
        System.out.println("Menghitung total biaya rental PC / PS4 ... ");
        return 0;
    }
    
}
    
//    int biayaPC(){
//        System.out.println("Total biaya rental PC = ");
//        return 0;
//    }
//    
//    int biayaPS() {
//        System.out.println("Total biaya rental PS4 = ");
//        return 0;
//    }


