/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package warnetrental;

public class rentalPC extends WarnetRental{
    
    float jam;
    int hargaperJam;
    
    public rentalPC(float jam, int hargaperJam) {
        this.jam = jam;
        this.hargaperJam = hargaperJam;
    }
    
    @Override
   public float hargaTotal(){
       return (int) (this.jam * this.hargaperJam);
   }
    
   
}
